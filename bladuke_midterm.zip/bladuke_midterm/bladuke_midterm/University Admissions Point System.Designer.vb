﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtGPA = New System.Windows.Forms.TextBox()
        Me.weirdBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.sat5 = New System.Windows.Forms.RadioButton()
        Me.sat4 = New System.Windows.Forms.RadioButton()
        Me.sat3 = New System.Windows.Forms.RadioButton()
        Me.sat2 = New System.Windows.Forms.RadioButton()
        Me.sat1 = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.hS6 = New System.Windows.Forms.RadioButton()
        Me.hS5 = New System.Windows.Forms.RadioButton()
        Me.hS4 = New System.Windows.Forms.RadioButton()
        Me.hS3 = New System.Windows.Forms.RadioButton()
        Me.hS2 = New System.Windows.Forms.RadioButton()
        Me.hS1 = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.dif6 = New System.Windows.Forms.RadioButton()
        Me.dif7 = New System.Windows.Forms.RadioButton()
        Me.dif5 = New System.Windows.Forms.RadioButton()
        Me.dif4 = New System.Windows.Forms.RadioButton()
        Me.dif3 = New System.Windows.Forms.RadioButton()
        Me.dif2 = New System.Windows.Forms.RadioButton()
        Me.dif1 = New System.Windows.Forms.RadioButton()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.TotalScore = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.geo3 = New System.Windows.Forms.CheckBox()
        Me.geo2 = New System.Windows.Forms.CheckBox()
        Me.geo1 = New System.Windows.Forms.CheckBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.alu2 = New System.Windows.Forms.CheckBox()
        Me.alu1 = New System.Windows.Forms.CheckBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.essay3 = New System.Windows.Forms.RadioButton()
        Me.essay2 = New System.Windows.Forms.RadioButton()
        Me.essay1 = New System.Windows.Forms.RadioButton()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.lAndS3 = New System.Windows.Forms.CheckBox()
        Me.lAndS2 = New System.Windows.Forms.CheckBox()
        Me.lAndS1 = New System.Windows.Forms.CheckBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.mis4 = New System.Windows.Forms.RadioButton()
        Me.mis3 = New System.Windows.Forms.RadioButton()
        Me.mis2 = New System.Windows.Forms.RadioButton()
        Me.mis1 = New System.Windows.Forms.RadioButton()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(276, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(63, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "GPA Score:"
        '
        'txtGPA
        '
        Me.txtGPA.Location = New System.Drawing.Point(345, 10)
        Me.txtGPA.Name = "txtGPA"
        Me.txtGPA.Size = New System.Drawing.Size(57, 20)
        Me.txtGPA.TabIndex = 1
        '
        'weirdBox
        '
        Me.weirdBox.Location = New System.Drawing.Point(421, 10)
        Me.weirdBox.Name = "weirdBox"
        Me.weirdBox.Size = New System.Drawing.Size(64, 20)
        Me.weirdBox.TabIndex = 2
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.sat5)
        Me.GroupBox1.Controls.Add(Me.sat4)
        Me.GroupBox1.Controls.Add(Me.sat3)
        Me.GroupBox1.Controls.Add(Me.sat2)
        Me.GroupBox1.Controls.Add(Me.sat1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 47)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(114, 139)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "SAT"
        '
        'sat5
        '
        Me.sat5.AutoSize = True
        Me.sat5.Location = New System.Drawing.Point(7, 112)
        Me.sat5.Name = "sat5"
        Me.sat5.Size = New System.Drawing.Size(97, 17)
        Me.sat5.TabIndex = 4
        Me.sat5.TabStop = True
        Me.sat5.Text = "1360-1600 [12]"
        Me.sat5.UseVisualStyleBackColor = True
        '
        'sat4
        '
        Me.sat4.AutoSize = True
        Me.sat4.Location = New System.Drawing.Point(7, 89)
        Me.sat4.Name = "sat4"
        Me.sat4.Size = New System.Drawing.Size(97, 17)
        Me.sat4.TabIndex = 3
        Me.sat4.TabStop = True
        Me.sat4.Text = "1200-1350 [11]"
        Me.sat4.UseVisualStyleBackColor = True
        '
        'sat3
        '
        Me.sat3.AutoSize = True
        Me.sat3.Location = New System.Drawing.Point(7, 66)
        Me.sat3.Name = "sat3"
        Me.sat3.Size = New System.Drawing.Size(97, 17)
        Me.sat3.TabIndex = 2
        Me.sat3.TabStop = True
        Me.sat3.Text = "1010-1190 [10]"
        Me.sat3.UseVisualStyleBackColor = True
        '
        'sat2
        '
        Me.sat2.AutoSize = True
        Me.sat2.Location = New System.Drawing.Point(7, 43)
        Me.sat2.Name = "sat2"
        Me.sat2.Size = New System.Drawing.Size(85, 17)
        Me.sat2.TabIndex = 1
        Me.sat2.TabStop = True
        Me.sat2.Text = "930-1000 [6]"
        Me.sat2.UseVisualStyleBackColor = True
        '
        'sat1
        '
        Me.sat1.AutoSize = True
        Me.sat1.Location = New System.Drawing.Point(7, 20)
        Me.sat1.Name = "sat1"
        Me.sat1.Size = New System.Drawing.Size(79, 17)
        Me.sat1.TabIndex = 0
        Me.sat1.TabStop = True
        Me.sat1.Text = "400-920 [0]"
        Me.sat1.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.hS6)
        Me.GroupBox2.Controls.Add(Me.hS5)
        Me.GroupBox2.Controls.Add(Me.hS4)
        Me.GroupBox2.Controls.Add(Me.hS3)
        Me.GroupBox2.Controls.Add(Me.hS2)
        Me.GroupBox2.Controls.Add(Me.hS1)
        Me.GroupBox2.Location = New System.Drawing.Point(144, 47)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(163, 139)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "High School Quality"
        '
        'hS6
        '
        Me.hS6.AutoSize = True
        Me.hS6.Location = New System.Drawing.Point(93, 99)
        Me.hS6.Name = "hS6"
        Me.hS6.Size = New System.Drawing.Size(52, 17)
        Me.hS6.TabIndex = 5
        Me.hS6.TabStop = True
        Me.hS6.Text = "5 [10]"
        Me.hS6.UseVisualStyleBackColor = True
        '
        'hS5
        '
        Me.hS5.AutoSize = True
        Me.hS5.Location = New System.Drawing.Point(93, 57)
        Me.hS5.Name = "hS5"
        Me.hS5.Size = New System.Drawing.Size(46, 17)
        Me.hS5.TabIndex = 4
        Me.hS5.TabStop = True
        Me.hS5.Text = "4 [8]"
        Me.hS5.UseVisualStyleBackColor = True
        '
        'hS4
        '
        Me.hS4.AutoSize = True
        Me.hS4.Location = New System.Drawing.Point(93, 20)
        Me.hS4.Name = "hS4"
        Me.hS4.Size = New System.Drawing.Size(46, 17)
        Me.hS4.TabIndex = 3
        Me.hS4.TabStop = True
        Me.hS4.Text = "3 [6]"
        Me.hS4.UseVisualStyleBackColor = True
        '
        'hS3
        '
        Me.hS3.AutoSize = True
        Me.hS3.Location = New System.Drawing.Point(7, 99)
        Me.hS3.Name = "hS3"
        Me.hS3.Size = New System.Drawing.Size(46, 17)
        Me.hS3.TabIndex = 2
        Me.hS3.TabStop = True
        Me.hS3.Text = "2 [4]"
        Me.hS3.UseVisualStyleBackColor = True
        '
        'hS2
        '
        Me.hS2.AutoSize = True
        Me.hS2.Location = New System.Drawing.Point(6, 57)
        Me.hS2.Name = "hS2"
        Me.hS2.Size = New System.Drawing.Size(46, 17)
        Me.hS2.TabIndex = 1
        Me.hS2.TabStop = True
        Me.hS2.Text = "1 [2]"
        Me.hS2.UseVisualStyleBackColor = True
        '
        'hS1
        '
        Me.hS1.AutoSize = True
        Me.hS1.Location = New System.Drawing.Point(7, 20)
        Me.hS1.Name = "hS1"
        Me.hS1.Size = New System.Drawing.Size(46, 17)
        Me.hS1.TabIndex = 0
        Me.hS1.TabStop = True
        Me.hS1.Text = "0 [0]"
        Me.hS1.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.dif6)
        Me.GroupBox3.Controls.Add(Me.dif7)
        Me.GroupBox3.Controls.Add(Me.dif5)
        Me.GroupBox3.Controls.Add(Me.dif4)
        Me.GroupBox3.Controls.Add(Me.dif3)
        Me.GroupBox3.Controls.Add(Me.dif2)
        Me.GroupBox3.Controls.Add(Me.dif1)
        Me.GroupBox3.Location = New System.Drawing.Point(322, 47)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(163, 139)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Difficulty of Curriculum"
        '
        'dif6
        '
        Me.dif6.AutoSize = True
        Me.dif6.Location = New System.Drawing.Point(93, 49)
        Me.dif6.Name = "dif6"
        Me.dif6.Size = New System.Drawing.Size(46, 17)
        Me.dif6.TabIndex = 6
        Me.dif6.TabStop = True
        Me.dif6.Text = "3 [6]"
        Me.dif6.UseVisualStyleBackColor = True
        '
        'dif7
        '
        Me.dif7.AutoSize = True
        Me.dif7.Location = New System.Drawing.Point(93, 80)
        Me.dif7.Name = "dif7"
        Me.dif7.Size = New System.Drawing.Size(46, 17)
        Me.dif7.TabIndex = 5
        Me.dif7.TabStop = True
        Me.dif7.Text = "4 [8]"
        Me.dif7.UseVisualStyleBackColor = True
        '
        'dif5
        '
        Me.dif5.AutoSize = True
        Me.dif5.Location = New System.Drawing.Point(93, 20)
        Me.dif5.Name = "dif5"
        Me.dif5.Size = New System.Drawing.Size(46, 17)
        Me.dif5.TabIndex = 4
        Me.dif5.TabStop = True
        Me.dif5.Text = "2 [4]"
        Me.dif5.UseVisualStyleBackColor = True
        '
        'dif4
        '
        Me.dif4.AutoSize = True
        Me.dif4.Location = New System.Drawing.Point(8, 112)
        Me.dif4.Name = "dif4"
        Me.dif4.Size = New System.Drawing.Size(46, 17)
        Me.dif4.TabIndex = 3
        Me.dif4.TabStop = True
        Me.dif4.Text = "1 [2]"
        Me.dif4.UseVisualStyleBackColor = True
        '
        'dif3
        '
        Me.dif3.AutoSize = True
        Me.dif3.Location = New System.Drawing.Point(7, 80)
        Me.dif3.Name = "dif3"
        Me.dif3.Size = New System.Drawing.Size(46, 17)
        Me.dif3.TabIndex = 2
        Me.dif3.TabStop = True
        Me.dif3.Text = "0 [0]"
        Me.dif3.UseVisualStyleBackColor = True
        '
        'dif2
        '
        Me.dif2.AutoSize = True
        Me.dif2.Location = New System.Drawing.Point(7, 49)
        Me.dif2.Name = "dif2"
        Me.dif2.Size = New System.Drawing.Size(52, 17)
        Me.dif2.TabIndex = 1
        Me.dif2.TabStop = True
        Me.dif2.Text = "-1 [-2]"
        Me.dif2.UseVisualStyleBackColor = True
        '
        'dif1
        '
        Me.dif1.AutoSize = True
        Me.dif1.Location = New System.Drawing.Point(7, 20)
        Me.dif1.Name = "dif1"
        Me.dif1.Size = New System.Drawing.Size(52, 17)
        Me.dif1.TabIndex = 0
        Me.dif1.TabStop = True
        Me.dif1.Text = "-2 [-4]"
        Me.dif1.UseVisualStyleBackColor = True
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(508, 8)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(215, 42)
        Me.btnCalculate.TabIndex = 7
        Me.btnCalculate.Text = "Calculate Total Score"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'TotalScore
        '
        Me.TotalScore.FormattingEnabled = True
        Me.TotalScore.Location = New System.Drawing.Point(508, 65)
        Me.TotalScore.Name = "TotalScore"
        Me.TotalScore.Size = New System.Drawing.Size(215, 121)
        Me.TotalScore.TabIndex = 8
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(319, 210)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(112, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Maximum  of 40 points"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.geo3)
        Me.GroupBox4.Controls.Add(Me.geo2)
        Me.GroupBox4.Controls.Add(Me.geo1)
        Me.GroupBox4.Location = New System.Drawing.Point(12, 244)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(197, 100)
        Me.GroupBox4.TabIndex = 10
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Geography"
        '
        'geo3
        '
        Me.geo3.AutoSize = True
        Me.geo3.Location = New System.Drawing.Point(7, 65)
        Me.geo3.Name = "geo3"
        Me.geo3.Size = New System.Drawing.Size(111, 17)
        Me.geo3.TabIndex = 2
        Me.geo3.Text = "Underrepresented"
        Me.geo3.UseVisualStyleBackColor = True
        '
        'geo2
        '
        Me.geo2.AutoSize = True
        Me.geo2.Location = New System.Drawing.Point(7, 42)
        Me.geo2.Name = "geo2"
        Me.geo2.Size = New System.Drawing.Size(111, 17)
        Me.geo2.TabIndex = 1
        Me.geo2.Text = "Underrepresented"
        Me.geo2.UseVisualStyleBackColor = True
        '
        'geo1
        '
        Me.geo1.AutoSize = True
        Me.geo1.Location = New System.Drawing.Point(7, 20)
        Me.geo1.Name = "geo1"
        Me.geo1.Size = New System.Drawing.Size(112, 17)
        Me.geo1.TabIndex = 0
        Me.geo1.Text = "State resident [10]"
        Me.geo1.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.alu2)
        Me.GroupBox5.Controls.Add(Me.alu1)
        Me.GroupBox5.Location = New System.Drawing.Point(12, 350)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(197, 100)
        Me.GroupBox5.TabIndex = 11
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Alumni"
        '
        'alu2
        '
        Me.alu2.AutoSize = True
        Me.alu2.Location = New System.Drawing.Point(7, 42)
        Me.alu2.Name = "alu2"
        Me.alu2.Size = New System.Drawing.Size(178, 17)
        Me.alu2.TabIndex = 1
        Me.alu2.Text = "Other (grandparents, siblings) [1]"
        Me.alu2.UseVisualStyleBackColor = True
        '
        'alu1
        '
        Me.alu1.AutoSize = True
        Me.alu1.Location = New System.Drawing.Point(7, 20)
        Me.alu1.Name = "alu1"
        Me.alu1.Size = New System.Drawing.Size(181, 17)
        Me.alu1.TabIndex = 0
        Me.alu1.Text = "Legacy (parents, stepparents) [4]"
        Me.alu1.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.essay3)
        Me.GroupBox6.Controls.Add(Me.essay2)
        Me.GroupBox6.Controls.Add(Me.essay1)
        Me.GroupBox6.Location = New System.Drawing.Point(237, 244)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(248, 100)
        Me.GroupBox6.TabIndex = 5
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Essay"
        '
        'essay3
        '
        Me.essay3.AutoSize = True
        Me.essay3.Location = New System.Drawing.Point(7, 66)
        Me.essay3.Name = "essay3"
        Me.essay3.Size = New System.Drawing.Size(97, 17)
        Me.essay3.TabIndex = 2
        Me.essay3.TabStop = True
        Me.essay3.Text = "Outstanding [3]"
        Me.essay3.UseVisualStyleBackColor = True
        '
        'essay2
        '
        Me.essay2.AutoSize = True
        Me.essay2.Location = New System.Drawing.Point(7, 43)
        Me.essay2.Name = "essay2"
        Me.essay2.Size = New System.Drawing.Size(83, 17)
        Me.essay2.TabIndex = 1
        Me.essay2.TabStop = True
        Me.essay2.Text = "Excellent [2]"
        Me.essay2.UseVisualStyleBackColor = True
        '
        'essay1
        '
        Me.essay1.AutoSize = True
        Me.essay1.Location = New System.Drawing.Point(7, 20)
        Me.essay1.Name = "essay1"
        Me.essay1.Size = New System.Drawing.Size(90, 17)
        Me.essay1.TabIndex = 0
        Me.essay1.TabStop = True
        Me.essay1.Text = "Very Good [1]"
        Me.essay1.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.lAndS3)
        Me.GroupBox7.Controls.Add(Me.lAndS2)
        Me.GroupBox7.Controls.Add(Me.lAndS1)
        Me.GroupBox7.Location = New System.Drawing.Point(237, 350)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(248, 100)
        Me.GroupBox7.TabIndex = 11
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Leadership and Service"
        '
        'lAndS3
        '
        Me.lAndS3.AutoSize = True
        Me.lAndS3.Location = New System.Drawing.Point(7, 65)
        Me.lAndS3.Name = "lAndS3"
        Me.lAndS3.Size = New System.Drawing.Size(80, 17)
        Me.lAndS3.TabIndex = 2
        Me.lAndS3.Text = "National [5]"
        Me.lAndS3.UseVisualStyleBackColor = True
        '
        'lAndS2
        '
        Me.lAndS2.AutoSize = True
        Me.lAndS2.Location = New System.Drawing.Point(7, 42)
        Me.lAndS2.Name = "lAndS2"
        Me.lAndS2.Size = New System.Drawing.Size(83, 17)
        Me.lAndS2.TabIndex = 1
        Me.lAndS2.Text = "Regional [2]"
        Me.lAndS2.UseVisualStyleBackColor = True
        '
        'lAndS1
        '
        Me.lAndS1.AutoSize = True
        Me.lAndS1.Location = New System.Drawing.Point(7, 20)
        Me.lAndS1.Name = "lAndS1"
        Me.lAndS1.Size = New System.Drawing.Size(66, 17)
        Me.lAndS1.TabIndex = 0
        Me.lAndS1.Text = "State [1]"
        Me.lAndS1.UseVisualStyleBackColor = True
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.mis4)
        Me.GroupBox8.Controls.Add(Me.mis3)
        Me.GroupBox8.Controls.Add(Me.mis2)
        Me.GroupBox8.Controls.Add(Me.mis1)
        Me.GroupBox8.Location = New System.Drawing.Point(508, 244)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(215, 206)
        Me.GroupBox8.TabIndex = 5
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Miscellaneous"
        '
        'mis4
        '
        Me.mis4.AutoSize = True
        Me.mis4.Location = New System.Drawing.Point(7, 170)
        Me.mis4.Name = "mis4"
        Me.mis4.Size = New System.Drawing.Size(137, 17)
        Me.mis4.TabIndex = 3
        Me.mis4.TabStop = True
        Me.mis4.Text = "Provost's discretion [20]"
        Me.mis4.UseVisualStyleBackColor = True
        '
        'mis3
        '
        Me.mis3.AutoSize = True
        Me.mis3.Location = New System.Drawing.Point(7, 118)
        Me.mis3.Name = "mis3"
        Me.mis3.Size = New System.Drawing.Size(133, 17)
        Me.mis3.TabIndex = 2
        Me.mis3.TabStop = True
        Me.mis3.Text = "Scholaship athlete [20]"
        Me.mis3.UseVisualStyleBackColor = True
        '
        'mis2
        '
        Me.mis2.AutoSize = True
        Me.mis2.Location = New System.Drawing.Point(7, 66)
        Me.mis2.Name = "mis2"
        Me.mis2.Size = New System.Drawing.Size(112, 17)
        Me.mis2.TabIndex = 1
        Me.mis2.TabStop = True
        Me.mis2.Text = "Men In Nursing [5]"
        Me.mis2.UseVisualStyleBackColor = True
        '
        'mis1
        '
        Me.mis1.AutoSize = True
        Me.mis1.Location = New System.Drawing.Point(7, 20)
        Me.mis1.Name = "mis1"
        Me.mis1.Size = New System.Drawing.Size(188, 17)
        Me.mis1.TabIndex = 0
        Me.mis1.TabStop = True
        Me.mis1.Text = "Socioeconomic Disadvantage [20]"
        Me.mis1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(750, 473)
        Me.Controls.Add(Me.GroupBox8)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TotalScore)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.weirdBox)
        Me.Controls.Add(Me.txtGPA)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "University Admissions Point System"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtGPA As TextBox
    Friend WithEvents weirdBox As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents sat5 As RadioButton
    Friend WithEvents sat4 As RadioButton
    Friend WithEvents sat3 As RadioButton
    Friend WithEvents sat2 As RadioButton
    Friend WithEvents sat1 As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents hS6 As RadioButton
    Friend WithEvents hS5 As RadioButton
    Friend WithEvents hS4 As RadioButton
    Friend WithEvents hS3 As RadioButton
    Friend WithEvents hS2 As RadioButton
    Friend WithEvents hS1 As RadioButton
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents dif6 As RadioButton
    Friend WithEvents dif7 As RadioButton
    Friend WithEvents dif5 As RadioButton
    Friend WithEvents dif4 As RadioButton
    Friend WithEvents dif3 As RadioButton
    Friend WithEvents dif2 As RadioButton
    Friend WithEvents dif1 As RadioButton
    Friend WithEvents btnCalculate As Button
    Friend WithEvents TotalScore As ListBox
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents geo3 As CheckBox
    Friend WithEvents geo2 As CheckBox
    Friend WithEvents geo1 As CheckBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents alu2 As CheckBox
    Friend WithEvents alu1 As CheckBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents essay3 As RadioButton
    Friend WithEvents essay2 As RadioButton
    Friend WithEvents essay1 As RadioButton
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents lAndS3 As CheckBox
    Friend WithEvents lAndS2 As CheckBox
    Friend WithEvents lAndS1 As CheckBox
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents mis4 As RadioButton
    Friend WithEvents mis3 As RadioButton
    Friend WithEvents mis2 As RadioButton
    Friend WithEvents mis1 As RadioButton
End Class
